define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./groovy.snippets");
exports.scope = "groovy";

});
